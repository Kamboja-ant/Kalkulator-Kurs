import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const KursApp());
}

class Currency {
  final String code;
  final String nameId;
  final String nameEn;
  final double perIdr;

  const Currency(this.code, this.nameId, this.nameEn, this.perIdr);
}

const currencies = <Currency>[
  Currency('IDR', 'Rupiah Indonesia', 'Indonesian Rupiah', 1),
  Currency('USD', 'Dolar Amerika', 'US Dollar', 16000),
  Currency('EUR', 'Euro', 'Euro', 18500),
  Currency('GBP', 'Pound Inggris', 'British Pound', 21500),
  Currency('JPY', 'Yen Jepang', 'Japanese Yen', 105),
  Currency('SGD', 'Dolar Singapura', 'Singapore Dollar', 12500),
  Currency('MYR', 'Ringgit Malaysia', 'Malaysian Ringgit', 3800),
  Currency('AUD', 'Dolar Australia', 'Australian Dollar', 10500),
  Currency('CNY', 'Yuan Tiongkok', 'Chinese Yuan', 2250),
  Currency('KRW', 'Won Korea Selatan', 'South Korean Won', 11.5),
  Currency('THB', 'Baht Thailand', 'Thai Baht', 460),
  Currency('PHP', 'Peso Filipina', 'Philippine Peso', 285),
  Currency('VND', 'Dong Vietnam', 'Vietnamese Dong', 0.64),
];

class KursApp extends StatefulWidget {
  const KursApp({super.key});

  @override
  State<KursApp> createState() => _KursAppState();
}

class _KursAppState extends State<KursApp> {
  bool english = false;
  bool dark = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kalkulator Kurs',
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      home: HomePage(
        english: english,
        dark: dark,
        onLanguage: () => setState(() => english = !english),
        onTheme: () => setState(() => dark = !dark),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final bool english;
  final bool dark;
  final VoidCallback onLanguage;
  final VoidCallback onTheme;

  const HomePage({
    super.key,
    required this.english,
    required this.dark,
    required this.onLanguage,
    required this.onTheme,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final input = TextEditingController(text: '100');
  Currency from = currencies[0];
  Currency to = currencies[1];

  double get amount => double.tryParse(input.text.replaceAll(',', '.')) ?? 0;
  double get result => amount * from.perIdr / to.perIdr;

  String format(double value) {
    if (value == value.roundToDouble()) return value.toStringAsFixed(0);
    return value.toStringAsFixed(2);
  }

  void swap() {
    setState(() {
      final old = from;
      from = to;
      to = old;
    });
  }

  void copyResult() {
    Clipboard.setData(ClipboardData(text: '${format(result)} ${to.code}'));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(widget.english ? 'Result copied' : 'Hasil disalin')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final en = widget.english;
    return Scaffold(
      appBar: AppBar(
        title: Text(en ? 'Currency Calculator' : 'Kalkulator Kurs'),
        actions: [
          IconButton(
            tooltip: en ? 'Language' : 'Bahasa',
            onPressed: widget.onLanguage,
            icon: const Icon(Icons.language),
          ),
          IconButton(
            tooltip: en ? 'Theme' : 'Tema',
            onPressed: widget.onTheme,
            icon: Icon(widget.dark ? Icons.light_mode : Icons.dark_mode),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                en ? 'Convert currency quickly' : 'Konversi mata uang dengan cepat',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 18),
              TextField(
                controller: input,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  labelText: en ? 'Amount' : 'Jumlah',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.calculate_outlined),
                ),
              ),
              const SizedBox(height: 14),
              CurrencyDropdown(
                label: en ? 'From' : 'Dari',
                value: from,
                english: en,
                onChanged: (v) => setState(() => from = v!),
              ),
              const SizedBox(height: 8),
              Center(
                child: IconButton.filledTonal(
                  tooltip: en ? 'Swap' : 'Tukar',
                  onPressed: swap,
                  icon: const Icon(Icons.swap_vert),
                ),
              ),
              const SizedBox(height: 8),
              CurrencyDropdown(
                label: en ? 'To' : 'Ke',
                value: to,
                english: en,
                onChanged: (v) => setState(() => to = v!),
              ),
              const SizedBox(height: 22),
              Card(
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    children: [
                      Text(en ? 'RESULT' : 'HASIL',
                          style: Theme.of(context).textTheme.labelLarge),
                      const SizedBox(height: 8),
                      Text(
                        '${format(result)} ${to.code}',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.displaySmall?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '1 ${from.code} ≈ ${format(from.perIdr / to.perIdr)} ${to.code}',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 14),
                      OutlinedButton.icon(
                        onPressed: copyResult,
                        icon: const Icon(Icons.copy),
                        label: Text(en ? 'Copy result' : 'Salin hasil'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                en
                    ? 'Demo rates are fixed sample values. Connect a live exchange-rate API before publishing.'
                    : 'Kurs demo menggunakan nilai contoh tetap. Hubungkan API kurs real-time sebelum dipublikasikan.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CurrencyDropdown extends StatelessWidget {
  final String label;
  final Currency value;
  final bool english;
  final ValueChanged<Currency?> onChanged;

  const CurrencyDropdown({
    super.key,
    required this.label,
    required this.value,
    required this.english,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<Currency>(
      value: value,
      isExpanded: true,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      items: currencies.map((c) {
        return DropdownMenuItem(
          value: c,
          child: Text('${c.code} — ${english ? c.nameEn : c.nameId}'),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }
}
