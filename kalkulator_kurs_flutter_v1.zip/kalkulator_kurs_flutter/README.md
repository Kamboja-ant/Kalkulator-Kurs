# Kalkulator Kurs Flutter

Aplikasi demo konversi mata uang dengan tampilan sederhana seperti kalkulator.

## Fitur versi 1.0
- Bahasa Indonesia dan English
- 13 mata uang
- Konversi dua arah
- Tombol tukar mata uang
- Salin hasil
- Light/Dark mode
- Struktur Flutter multi-platform

> Nilai kurs di versi ini adalah nilai contoh tetap, bukan kurs real-time. Untuk versi produksi, tambahkan API kurs real-time dan mekanisme cache/error handling.

## Menjalankan
Pastikan Flutter SDK sudah terpasang.

```bash
flutter pub get
flutter run
```

Untuk Android:
```bash
flutter devices
flutter run -d <ID_PERANGKAT>
```

Untuk Web:
```bash
flutter run -d chrome
```

Flutter juga menyediakan perintah `flutter create`, `flutter analyze`, `flutter test`, dan `flutter run` untuk membuat, memeriksa, menguji, dan menjalankan aplikasi.
