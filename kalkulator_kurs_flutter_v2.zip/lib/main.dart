import 'package:flutter/material.dart';

void main() => runApp(const CurrencyCalculatorApp());

class CurrencyCalculatorApp extends StatefulWidget {
  const CurrencyCalculatorApp({super.key});
  @override
  State<CurrencyCalculatorApp> createState() => _CurrencyCalculatorAppState();
}

class _CurrencyCalculatorAppState extends State<CurrencyCalculatorApp> {
  bool english = false;
  String from = 'IDR';
  String to = 'USD';
  String input = '100000';

  static const ratesToUsd = <String, double>{
    'IDR': 1 / 16500,
    'USD': 1,
    'EUR': 1.17,
    'GBP': 1.35,
    'JPY': 1 / 148,
    'SGD': 0.78,
    'MYR': 0.25,
    'THB': 1 / 32.5,
    'AUD': 0.65,
    'CNY': 0.14,
    'KRW': 1 / 1380,
    'HKD': 0.128,
    'VND': 1 / 26000,
  };

  static const namesId = <String, String>{
    'IDR': 'Rupiah Indonesia', 'USD': 'Dolar AS', 'EUR': 'Euro',
    'GBP': 'Pound Inggris', 'JPY': 'Yen Jepang', 'SGD': 'Dolar Singapura',
    'MYR': 'Ringgit Malaysia', 'THB': 'Baht Thailand', 'AUD': 'Dolar Australia',
    'CNY': 'Yuan Tiongkok', 'KRW': 'Won Korea', 'HKD': 'Dolar Hong Kong',
    'VND': 'Dong Vietnam',
  };

  double get result {
    final value = double.tryParse(input) ?? 0;
    final usd = value * ratesToUsd[from]!;
    return usd / ratesToUsd[to]!;
  }

  String formatNumber(double value) {
    if (value.abs() >= 1000000) return value.toStringAsFixed(2);
    if (value == value.roundToDouble()) return value.toStringAsFixed(0);
    return value.toStringAsFixed(2);
  }

  void key(String value) {
    setState(() {
      if (value == 'C') {
        input = '0';
      } else if (value == '⌫') {
        input = input.length > 1 ? input.substring(0, input.length - 1) : '0';
      } else if (value == '.') {
        if (!input.contains('.')) input += '.';
      } else {
        if (input == '0') input = value; else if (input.length < 15) input += value;
      }
    });
  }

  void swap() => setState(() { final x = from; from = to; to = x; });

  @override
  Widget build(BuildContext context) {
    final title = english ? 'Currency Calculator' : 'Kalkulator Kurs';
    final fromLabel = english ? 'From' : 'Dari';
    final toLabel = english ? 'To' : 'Ke';
    final rateLabel = english ? 'Indicative rate • offline' : 'Kurs indikatif • offline';
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: title,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        appBar: AppBar(
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            TextButton(onPressed: () => setState(() => english = !english), child: Text(english ? 'ID' : 'EN')),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Row(children: [
                  Expanded(child: _currencyCard(fromLabel, from, (v) => setState(() => from = v!))),
                  IconButton(onPressed: swap, icon: const Icon(Icons.swap_horiz_rounded, size: 32)),
                  Expanded(child: _currencyCard(toLabel, to, (v) => setState(() => to = v!))),
                ]),
              ),
              Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(22)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('$input $from', style: const TextStyle(fontSize: 22)),
                  const SizedBox(height: 6),
                  FittedBox(child: Text('${formatNumber(result)} $to', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800))),
                  const SizedBox(height: 8),
                  Text(rateLabel, style: TextStyle(color: Theme.of(context).colorScheme.onPrimaryContainer.withValues(alpha: .7), fontSize: 12)),
                ]),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 3,
                  padding: const EdgeInsets.all(14),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.55,
                  children: ['7','8','9','4','5','6','1','2','3','C','0','.','⌫'].map((v) => _key(v)).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _currencyCard(String label, String value, ValueChanged<String?> onChanged) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(left: 4, bottom: 4), child: Text(label, style: const TextStyle(fontSize: 12))),
        DropdownButtonFormField<String>(
          initialValue: value,
          isExpanded: true,
          decoration: const InputDecoration(border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8)),
          items: ratesToUsd.keys.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
          onChanged: onChanged,
        ),
      ]);

  Widget _key(String value) => FilledButton.tonal(
    onPressed: () => key(value),
    style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    child: Text(value, style: TextStyle(fontSize: value == '⌫' ? 24 : 20, fontWeight: FontWeight.bold)),
  );
}
