# Kalkulator Kurs

Aplikasi Flutter kalkulator konversi mata uang sederhana, offline, dengan Bahasa Indonesia dan English.

Kurs contoh disimpan di `lib/main.dart` dan dapat diperbarui kemudian.
