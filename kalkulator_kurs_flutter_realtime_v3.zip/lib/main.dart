import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const CurrencyCalculatorApp());

class CurrencyCalculatorApp extends StatefulWidget {
  const CurrencyCalculatorApp({super.key});

  @override
  State<CurrencyCalculatorApp> createState() => _CurrencyCalculatorAppState();
}

class _CurrencyCalculatorAppState extends State<CurrencyCalculatorApp> {
  bool english = false;
  bool loading = false;
  String? error;
  String from = 'IDR';
  String to = 'USD';
  String input = '100000';
  double? rate;
  DateTime? updatedAt;
  String? source;
  String? marketSession;
  Timer? refreshTimer;

  static const apiBase = 'https://api.exchangerate.dev/v1/latest';

  static const currencies = <String, String>{
    'IDR': 'Rupiah Indonesia',
    'USD': 'Dolar Amerika',
    'EUR': 'Euro',
    'GBP': 'Pound Inggris',
    'JPY': 'Yen Jepang',
    'SGD': 'Dolar Singapura',
    'MYR': 'Ringgit Malaysia',
    'THB': 'Baht Thailand',
    'AUD': 'Dolar Australia',
    'CNY': 'Yuan Tiongkok',
    'KRW': 'Won Korea Selatan',
    'HKD': 'Dolar Hong Kong',
    'VND': 'Dong Vietnam',
  };

  @override
  void initState() {
    super.initState();
    _loadCachedRate();
    _refreshRate();
    refreshTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      _refreshRate(silent: true);
    });
  }

  @override
  void dispose() {
    refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadCachedRate() async {
    final prefs = await SharedPreferences.getInstance();
    final key = '${from}_$to';
    final cached = prefs.getDouble('rate_$key');
    final cachedAtMs = prefs.getInt('updated_$key');
    if (!mounted || cached == null) return;
    setState(() {
      rate = cached;
      updatedAt = cachedAtMs == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(cachedAtMs);
      source = 'cache';
      marketSession = 'offline';
    });
  }

  Future<void> _refreshRate({bool silent = false}) async {
    if (from == to) {
      setState(() {
        rate = 1;
        updatedAt = DateTime.now();
        source = 'same currency';
        marketSession = null;
        error = null;
        loading = false;
      });
      return;
    }

    if (!silent && mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }

    try {
      final uri = Uri.parse('$apiBase/$from?symbols=$to');
      final response = await http.get(uri).timeout(const Duration(seconds: 12));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('HTTP ${response.statusCode}');
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final rates = data['rates'] as Map<String, dynamic>?;
      final value = (rates?[to] as num?)?.toDouble();
      if (value == null || value <= 0) throw Exception('Rate tidak tersedia');

      final timestamp = DateTime.tryParse(data['timestamp']?.toString() ?? '');
      final prefs = await SharedPreferences.getInstance();
      final key = '${from}_$to';
      await prefs.setDouble('rate_$key', value);
      await prefs.setInt(
        'updated_$key',
        (timestamp ?? DateTime.now()).millisecondsSinceEpoch,
      );

      if (!mounted) return;
      setState(() {
        rate = value;
        updatedAt = timestamp ?? DateTime.now();
        source = data['source']?.toString() ?? 'live';
        marketSession = data['market_session']?.toString();
        error = null;
        loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = english
            ? 'Internet unavailable. Showing the last saved rate.'
            : 'Internet tidak tersedia. Menampilkan kurs terakhir yang tersimpan.';
        source ??= 'cache';
      });
    }
  }

  double? get result {
    final value = double.tryParse(input.replaceAll(',', '.')) ?? 0;
    if (rate == null) return null;
    return value * rate!;
  }

  String formatNumber(double value) {
    if (value.abs() >= 1000000000) return value.toStringAsFixed(2);
    if (value.abs() >= 1000000) return value.toStringAsFixed(2);
    if (value == value.roundToDouble()) return value.toStringAsFixed(0);
    return value.toStringAsFixed(2);
  }

  void key(String value) {
    setState(() {
      if (value == 'C') {
        input = '0';
      } else if (value == '⌫') {
        input = input.length > 1 ? input.substring(0, input.length - 1) : '0';
      } else if (value == '.') {
        if (!input.contains('.')) input += '.';
      } else {
        if (input == '0') {
          input = value;
        } else if (input.length < 15) {
          input += value;
        }
      }
    });
  }

  void changeFrom(String value) {
    setState(() => from = value);
    _loadCachedRate();
    _refreshRate();
  }

  void changeTo(String value) {
    setState(() => to = value);
    _loadCachedRate();
    _refreshRate();
  }

  void swap() {
    setState(() {
      final x = from;
      from = to;
      to = x;
    });
    _loadCachedRate();
    _refreshRate();
  }

  String _timeLabel() {
    if (updatedAt == null) return '';
    final t = updatedAt!.toLocal();
    final hh = t.hour.toString().padLeft(2, '0');
    final mm = t.minute.toString().padLeft(2, '0');
    return '$hh:$mm';
  }

  @override
  Widget build(BuildContext context) {
    final title = english ? 'Currency Calculator' : 'Kalkulator Kurs';
    final subtitle = english
        ? 'Live exchange rates for travelers'
        : 'Kurs mata uang real-time untuk wisatawan';
    final fromLabel = english ? 'From' : 'Dari';
    final toLabel = english ? 'To' : 'Ke';
    final resultLabel = english ? 'RESULT' : 'HASIL';
    final liveLabel = english ? 'LIVE RATE' : 'KURS REAL-TIME';

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: title,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: Scaffold(
        appBar: AppBar(
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(
              tooltip: english ? 'Refresh rate' : 'Perbarui kurs',
              onPressed: loading ? null : _refreshRate,
              icon: loading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.refresh_rounded),
            ),
            TextButton(
              onPressed: () => setState(() => english = !english),
              child: Text(english ? 'ID' : 'EN'),
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(subtitle, style: TextStyle(color: Colors.grey.shade700)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                child: Row(
                  children: [
                    Expanded(child: _currencyCard(fromLabel, from, changeFrom)),
                    IconButton(
                      onPressed: swap,
                      icon: const Icon(Icons.swap_horiz_rounded, size: 32),
                    ),
                    Expanded(child: _currencyCard(toLabel, to, changeTo)),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          liveLabel,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                        Text('$input $from', style: const TextStyle(fontSize: 20)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    FittedBox(
                      child: Text(
                        result == null ? '—' : '${formatNumber(result!)} $to',
                        style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      rate == null
                          ? (english ? 'Waiting for rate…' : 'Menunggu kurs…')
                          : '1 $from ≈ ${formatNumber(rate!)} $to',
                      style: TextStyle(
                        color: Theme.of(context)
                            .colorScheme
                            .onPrimaryContainer
                            .withValues(alpha: .75),
                        fontSize: 13,
                      ),
                    ),
                    if (updatedAt != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        '${english ? 'Updated' : 'Diperbarui'} ${_timeLabel()}${source == 'cache' ? ' • ${english ? 'offline cache' : 'cache offline'}' : ''}',
                        style: TextStyle(
                          color: Theme.of(context)
                              .colorScheme
                              .onPrimaryContainer
                              .withValues(alpha: .65),
                          fontSize: 11,
                        ),
                      ),
                    ],
                    if (error != null) ...[
                      const SizedBox(height: 6),
                      Text(
                        error!,
                        textAlign: TextAlign.right,
                        style: TextStyle(color: Theme.of(context).colorScheme.error, fontSize: 11),
                      ),
                    ],
                    if (marketSession != null && marketSession != 'offline') ...[
                      const SizedBox(height: 4),
                      Text(
                        '${english ? 'Market' : 'Pasar'}: $marketSession',
                        style: const TextStyle(fontSize: 10),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 3,
                  padding: const EdgeInsets.all(14),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.55,
                  children: ['7', '8', '9', '4', '5', '6', '1', '2', '3', 'C', '0', '.', '⌫']
                      .map((v) => _key(v))
                      .toList(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Text(
                  english
                      ? 'Rates are indicative. Internet is required for fresh rates.'
                      : 'Kurs bersifat indikatif. Internet diperlukan untuk kurs terbaru.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 10, color: Colors.grey.shade600),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _currencyCard(String label, String value, ValueChanged<String> onChanged) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 4),
            child: Text(label, style: const TextStyle(fontSize: 12)),
          ),
          DropdownButtonFormField<String>(
            initialValue: value,
            isExpanded: true,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            ),
            items: currencies.keys
                .map(
                  (c) => DropdownMenuItem(
                    value: c,
                    child: Text('$c — ${english ? _englishName(c) : currencies[c]!}', overflow: TextOverflow.ellipsis),
                  ),
                )
                .toList(),
            onChanged: (v) {
              if (v != null) onChanged(v);
            },
          ),
        ],
      );

  String _englishName(String code) {
    const names = {
      'IDR': 'Indonesian Rupiah',
      'USD': 'US Dollar',
      'EUR': 'Euro',
      'GBP': 'British Pound',
      'JPY': 'Japanese Yen',
      'SGD': 'Singapore Dollar',
      'MYR': 'Malaysian Ringgit',
      'THB': 'Thai Baht',
      'AUD': 'Australian Dollar',
      'CNY': 'Chinese Yuan',
      'KRW': 'South Korean Won',
      'HKD': 'Hong Kong Dollar',
      'VND': 'Vietnamese Dong',
    };
    return names[code] ?? code;
  }

  Widget _key(String value) => FilledButton.tonal(
        onPressed: () => key(value),
        style: FilledButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        child: Text(
          value,
          style: TextStyle(fontSize: value == '⌫' ? 24 : 20, fontWeight: FontWeight.bold),
        ),
      );
}
