# Kalkulator Kurs Real-Time v1.1

Flutter currency calculator for travelers with:
- Indonesian / English UI
- 13 travel currencies
- Live exchange-rate refresh from exchangerate.dev
- Automatic refresh every 1 minute while the app is open
- Last-known-rate cache when internet is unavailable
- Calculator-style keypad
- Responsive Material 3 layout

## Data source
The app uses the exchangerate.dev JSON endpoint without an API key for evaluation. Major currencies can update about every 60 seconds on trading days; some currencies such as IDR may use a reference rate and can update less frequently. The app displays the provider source/session when available.

For a public production release, create a free API key with the provider and follow its usage/attribution terms.

## Run
1. Install Flutter.
2. `flutter pub get`
3. `flutter run`

## Build
- Android: `flutter build apk --release`
- Web: `flutter build web --release`
- Windows: `flutter build windows --release`
- macOS: `flutter build macos --release`
- Linux: `flutter build linux --release`
