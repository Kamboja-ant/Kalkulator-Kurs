import 'package:flutter_test/flutter_test.dart';
import 'package:kalkulator_kurs/main.dart';

void main() {
  testWidgets('app starts', (tester) async {
    await tester.pumpWidget(const CurrencyCalculatorApp());
    expect(find.text('Kalkulator Kurs'), findsOneWidget);
  });
}
